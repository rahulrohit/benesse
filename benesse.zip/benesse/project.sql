-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2024 at 05:28 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(2, 'admin@admin.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `qid` text NOT NULL,
  `ansid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`qid`, `ansid`) VALUES
('65b934f317de4', '65b934f318ab2'),
('65b934f31c6ce', '65b934f31cb98'),
('65b934f31defd', '65b934f31ea84'),
('65b934f3200de', '65b934f320503'),
('65b934f3219ab', '65b934f321ebc'),
('65b9cbf8d7fe7', '65b9cbf8d87b0');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `email` varchar(50) NOT NULL,
  `eid` text NOT NULL,
  `score` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`email`, `eid`, `score`, `level`, `sahi`, `wrong`, `date`) VALUES
('rahul@gmail.com', '65b9cbd521103', 1, 1, 1, 0, '2024-01-31 04:26:56'),
('rahul@gmail.com', '65b933bbb9982', 25, 5, 5, 0, '2024-01-31 04:27:46');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `qid` varchar(50) NOT NULL,
  `option` varchar(5000) NOT NULL,
  `optionid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`qid`, `option`, `optionid`) VALUES
('65b934f317de4', 'Programming language', '65b934f318ab2'),
('65b934f317de4', 'Gaming language', '65b934f318ab7'),
('65b934f317de4', 'Nothing', '65b934f318ab8'),
('65b934f317de4', 'All of the above', '65b934f318ab9'),
('65b934f31c6ce', 'Query language', '65b934f31cb98'),
('65b934f31c6ce', 'Programming language', '65b934f31cb99'),
('65b934f31c6ce', 'Gaming language', '65b934f31cb9a'),
('65b934f31c6ce', 'Nothing', '65b934f31cb9b'),
('65b934f31defd', 'MNC company', '65b934f31ea7f'),
('65b934f31defd', 'Education Company', '65b934f31ea82'),
('65b934f31defd', 'NGO', '65b934f31ea83'),
('65b934f31defd', 'Startup', '65b934f31ea84'),
('65b934f3200de', 'Ratanlal', '65b934f320501'),
('65b934f3200de', 'Ratan Tata', '65b934f320503'),
('65b934f3200de', 'Ram', '65b934f320504'),
('65b934f3200de', 'Shyam', '65b934f320505'),
('65b934f3219ab', 'ABC', '65b934f321ebb'),
('65b934f3219ab', 'Modi ji', '65b934f321ebc'),
('65b934f3219ab', 'Rahul Gandhi', '65b934f321ebd'),
('65b934f3219ab', 'Nitish kumar', '65b934f321ebe'),
('65b9cbf8d7fe7', 'SQL query', '65b9cbf8d87b0'),
('65b9cbf8d7fe7', 'view query', '65b9cbf8d87be'),
('65b9cbf8d7fe7', 'DB query', '65b9cbf8d87bf'),
('65b9cbf8d7fe7', 'Nothing', '65b9cbf8d87c0');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `eid` text NOT NULL,
  `qid` text NOT NULL,
  `qns` text NOT NULL,
  `choice` int(10) NOT NULL,
  `sn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`eid`, `qid`, `qns`, `choice`, `sn`) VALUES
('65b933bbb9982', '65b934f317de4', 'What is php?', 4, 1),
('65b933bbb9982', '65b934f31c6ce', 'What is mysql ?', 4, 2),
('65b933bbb9982', '65b934f31defd', 'What is beneess india?', 4, 3),
('65b933bbb9982', '65b934f3200de', 'Who is founder of TCS?', 4, 4),
('65b933bbb9982', '65b934f3219ab', 'Who is PM of india?', 4, 5),
('65b9cbd521103', '65b9cbf8d7fe7', 'What os mysql use?', 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `eid` text NOT NULL,
  `title` varchar(100) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `time` bigint(20) NOT NULL,
  `intro` text NOT NULL,
  `tag` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`eid`, `title`, `sahi`, `wrong`, `total`, `time`, `intro`, `tag`, `date`) VALUES
('65b933bbb9982', 'Php Test', 5, 0, 5, 5, 'Test php', '', '2024-01-30 17:36:59'),
('65b9cbd521103', 'Mysql Test', 1, 0, 1, 5, 'Test', '', '2024-01-31 04:25:57');

-- --------------------------------------------------------

--
-- Table structure for table `rank`
--

CREATE TABLE `rank` (
  `email` varchar(50) NOT NULL,
  `score` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `rank`
--

INSERT INTO `rank` (`email`, `score`, `time`) VALUES
('rahul@gmail.com', 26, '2024-01-31 04:27:46');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(50) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `college` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mob` bigint(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `gender`, `college`, `email`, `mob`, `password`) VALUES
('Rahul', 'M', 'MUIT', 'rahul@gmail.com', 9205261651, 'e10adc3949ba59abbe56e057f20f883e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
