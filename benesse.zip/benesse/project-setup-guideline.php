Installation Steps 
1. Download zip file and Unzip file on your local server.
2. Put this file inside "c:/xampp/htdocs/benesse"
3. Database Configuration Open phpmyadmin Create Database named project. Import database project.sql from downloaded folder 
4. Open Your browser put inside "http://localhost/benesse/"
5. To Login as admin put Login Id: admin@gmail.com & password : admin
6. Login as Student put login id : rahul@gmail.com & password : 123456
